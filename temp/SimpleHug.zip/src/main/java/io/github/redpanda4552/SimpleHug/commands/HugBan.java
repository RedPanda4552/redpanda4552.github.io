/**
 * This file is part of SimpleHug, licensed under the MIT License (MIT)
 * 
 * Copyright (c) 2014 Brian Wood
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package io.github.redpanda4552.SimpleHug.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import io.github.redpanda4552.SimpleHug.SimpleHugCommand;
import io.github.redpanda4552.SimpleHug.SimpleHugMain;

public class HugBan extends SimpleHugCommand {

	public HugBan(SimpleHugMain main) {
		super(main);
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender sender, Command command,	String label, String[] args) {
		if (args.length >= 1) {
			if (Bukkit.getPlayer(args[0]) != null) {
				Player toHugBan = Bukkit.getPlayer(args[0]);
				hugBan(toHugBan, sender);
			}
		}
		return true;
	}

	/**
	 * Modify the ban status of a player in question. If no entry exists in the ban list,
	 * one is added, and marked as true. If an entry exists, whatever state it is in is flipped.
	 * @param toBan - The player to modify ban status for.
	 * @param sender - The CommandSender who executed the ban.
	 */
	public void hugBan(Player toHugBan, CommandSender sender) {
		String uuid = toHugBan.getUniqueId().toString();
		if (main.banList.contains(uuid)) {
			if (main.banList.getBoolean(uuid) == false) {
				main.banList.set(uuid, true);
				sender.sendMessage(tag + "Banning " + toHugBan.getName() + " from hugging.");
			} else {
				main.banList.set(uuid, false);
				sender.sendMessage(tag + "Reversing " + toHugBan.getName() + "'s hug ban.");
			}
		} else {
			main.banList.addDefault(uuid, true);
			sender.sendMessage(tag + "Banning " + toHugBan.getName() + " from hugging.");
		}
	}
}
