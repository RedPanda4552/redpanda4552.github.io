/**
 * This file is part of SimpleHug, licensed under the MIT License (MIT)
 * 
 * Copyright (c) 2014 Brian Wood
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package io.github.redpanda4552.SimpleHug;

import io.github.redpanda4552.SimpleHug.commands.HugBan;
import io.github.redpanda4552.SimpleHug.random.EventListener;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;
import java.util.logging.Logger;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class SimpleHugMain extends JavaPlugin {

	public Logger log;
	
	private HugBan hugban;
	
	private File banListFile;
	public YamlConfiguration banList;
	
	/**
	 * The number of hugs required to make /breakarm an option.
	 */
	public static int breakThreshold;
	
	public ArrayList<UUID> breakList = new ArrayList<UUID>();
	
	public void onEnable() {
		this.log = this.getLogger();
		
		this.getServer().getPluginManager().registerEvents(new EventListener(), this);
		
		this.saveDefaultConfig();
		breakThreshold = this.getConfig().getInt("hugs-to-break-arm");
		
		this.banListFile = new File("plugins/simplehug/banlist.yml");
		if (!banListFile.exists()) {
			log.info("Generating new hug ban list.");
			this.saveResource("banlist.yml", false);
		}
		this.banList = YamlConfiguration.loadConfiguration(this.banListFile);
		
		this.hugban = new HugBan(this);
		
		getCommand("hugban").setExecutor(hugban);
		getCommand("hugban").setPermissionMessage(ChatColor.RED + getCommand("hugban").getPermissionMessage());
		getCommand("breakarm").setPermissionMessage(ChatColor.RED + getCommand("breakarm").getPermissionMessage());
	}
	
	public void onDisable() {
		//Save the Ban List's current state.
		try {
			this.banList.save(banListFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}