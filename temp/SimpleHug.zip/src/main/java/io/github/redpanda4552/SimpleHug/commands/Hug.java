/**
 * This file is part of SimpleHug, licensed under the MIT License (MIT)
 * 
 * Copyright (c) 2014 Brian Wood
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package io.github.redpanda4552.SimpleHug.commands;

import io.github.redpanda4552.SimpleHug.ResetWalkSpeedTask;
import io.github.redpanda4552.SimpleHug.SimpleHugCommand;
import io.github.redpanda4552.SimpleHug.SimpleHugMain;

import java.util.HashSet;

import org.bukkit.Bukkit;
import org.bukkit.block.CommandBlock;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class Hug extends SimpleHugCommand {

	private BlockCommandSender bcs;
	private CommandBlock bcsBlock;
	private ConsoleCommandSender ccs; //Unused, but keeping it in case it becomes useful down the road.
	private Player p;
	
	public Hug(SimpleHugMain main) {
		super(main);
	}

	@Override
	public boolean onCommand(CommandSender sender, Command command,	String label, String[] args) {
		
		if (sender instanceof Player) {
			p = (Player) sender;
		} else if (sender instanceof BlockCommandSender) {
			bcs = (BlockCommandSender) sender;
			bcsBlock = (CommandBlock) bcs.getBlock();
			if (main.getConfig().getBoolean("allow-command-block-use") == false) {
				main.log.info("A command block at x:" + bcsBlock.getX() + " y:" + bcsBlock.getY() + " z:" + bcsBlock.getZ() +
							  " tried to hug someone, but is not allowed to.");
				return true;
			}			
			
			if (bcsBlock.getName().equalsIgnoreCase("@")) {
				bcsBlock.setName("A Command Block");
			}
		} else if (sender instanceof ConsoleCommandSender) {
			if (main.getConfig().getBoolean("allow-console-use") == false) {
				sender.sendMessage(tag + "You cannot use SimpleHug in the console.");
				return true;
			}
			
			ccs = (ConsoleCommandSender) sender;
		} else {
			main.log.warning("Unrecognized CommandSender subclass while executing " + command.getName() + "! Ignoring it. " + 
							 "Name of sender: " + sender.getName() + " Outputing object as String: " + sender.toString());
			return true;
		}
		
		if (args.length >= 1) {
			//Hug all situations. If all conditions are not met, it just treats it as a normal hug.
			if (args.length == 1 && args[0].equals("*") && sender.hasPermission("SimpleHug.hugall")) {
				execute(sender, Bukkit.getOnlinePlayers(), command, true);
				return true;
			}
			
			//Any other case 				
			HashSet<Player> playerSet = new HashSet<Player>();
			for (String name : args) {
				if (Bukkit.getServer().getPlayer(name) != null) {
					if (p != null) {
						if (p.canSee(Bukkit.getServer().getPlayer(name))) {
							playerSet.add(Bukkit.getServer().getPlayer(name));
						} else {
							sender.sendMessage(tag + "Player " + name + " was not found.");
						}
					} else {
						playerSet.add(Bukkit.getServer().getPlayer(name));
					}
					
				} else {
					sender.sendMessage(tag + "Player " + name + " was not found.");
				}
			}
			execute(sender, (Player[]) playerSet.toArray(), command, false);
			return true;
		}
		
		sender.sendMessage(tag + "/hug [<player1> <player2> ...]");
		return true;
	}
	
	/**
	 * This method is more of a hand-off mechanic that fires the appropriate hug type.
	 * This way I can call this method, instead of pasting in this logic block.
	 * @param hugger - The hugging entitiy, whether it be a Player, Command Block, or the Console.
	 * @param toHug - Array of Players who are to be hugged.
	 * @param command - The command that was used.
	 * @param hugAll - Whether or not this is a hug-all situation.
	 */
	private void execute(CommandSender hugger, Player[] toHug, Command command, boolean hugAll) {
		if (command.getName().equalsIgnoreCase("hug")) {
			hug(hugger, toHug, hugAll);
		} else if (command.getName().equalsIgnoreCase("squishyhug")) {
			squishyhug(hugger, toHug, hugAll);
		} else if (command.getName().equalsIgnoreCase("tacklehug")) {
			tacklehug(hugger, toHug, hugAll);
		} else if (command.getName().equalsIgnoreCase("glomp")) {
			glomp(hugger, toHug, hugAll);
		}
	}
	
	/**
	 * Carries out normal hugs.
	 * @param hugger - The hugging entitiy, whether it be a Player, Command Block, or the Console.
	 * @param toHug - Array of Players who are to be hugged.
	 * @param hugAll - Whether or not this is a hug-all situation.
	 */
	private void hug(CommandSender hugger, Player[] toHug, boolean hugAll) {
		for (Player player : toHug) {
			player.sendMessage(tag + hugger.getName() + " hugs you!");
			if (!hugAll) {
				hugger.sendMessage(tag + "You hugged " + player.getName() + "!");
			}
		}
		if (hugAll) {
			hugger.sendMessage(tag + "You hugged everyone!");
		}
	}
	
	/**
	 * Carries out squishy hugs.
	 * @param hugger - The hugging entitiy, whether it be a Player, Command Block, or the Console.
	 * @param toHug - Array of Players who are to be hugged.
	 * @param hugAll - Whether or not this is a hug-all situation.
	 */
	private void squishyhug(CommandSender hugger, Player[] toHug, boolean hugAll) {
		for (Player player : toHug) {
			player.sendMessage(tag + hugger.getName() + " is squishing you!");
			player.setWalkSpeed(0.1F);
			new ResetWalkSpeedTask(player).runTaskLater(main, main.getConfig().getInt("squishyhug-time") * 20);
			if (!hugAll) {
				hugger.sendMessage(tag + "You squished " + player.getName() + "!");
			}
		}
		if (hugAll) {
			hugger.sendMessage(tag + "You squished everyone!");
		}
	}
	
	/**
	 * Carries out tackle hugs.
	 * @param hugger - The hugging entitiy, whether it be a Player, Command Block, or the Console.
	 * @param toHug - Array of Players who are to be hugged.
	 * @param hugAll - Whether or not this is a hug-all situation.
	 */
	private void tacklehug(CommandSender hugger, Player[] toHug, boolean hugAll) {
		for (Player player : toHug) {
			player.sendMessage(tag + hugger.getName() + " tackle hugs you!");
			Vector v = new Vector(player.getLocation().getDirection().getX(), -0.4, player.getLocation().getDirection().getZ());
			Vector vf = v.multiply(-1 * main.getConfig().getInt("tackle-knockback"));
			player.damage(0);
			player.setVelocity(vf);
			if (!hugAll) {
				hugger.sendMessage(tag + "You tackle hugged " + player.getName() + "!");
			}
		}
		if (hugAll) {
			hugger.sendMessage(tag + "You tackle hugged everyone!");
		}
	}
	
	/**
	 * Carries out glomps.
	 * @param hugger - The hugging entitiy, whether it be a Player, Command Block, or the Console.
	 * @param toHug - Array of Players who are to be hugged.
	 * @param hugAll - Whether or not this is a hug-all situation.
	 */
	private void glomp(CommandSender hugger, Player[] toHug, boolean hugAll) {
		for (Player player : toHug) {
			player.sendMessage(tag + hugger.getName() + " is glomping you!");
			Vector v = new Vector(player.getLocation().getDirection().getX(), -0.4, player.getLocation().getDirection().getZ());
			Vector vf = v.multiply(-1);
			player.damage(0);
			player.setVelocity(vf);
			player.setWalkSpeed(0.1F);
			new ResetWalkSpeedTask(player).runTaskLater(main, main.getConfig().getInt("squishyhug-time") * 20);
			if (!hugAll) {
				hugger.sendMessage(tag + "You glomped " + player.getName() + "!");
			}
		}
		if (hugAll) {
			hugger.sendMessage(tag + "You glomped everyone!");
		}
	}
}
